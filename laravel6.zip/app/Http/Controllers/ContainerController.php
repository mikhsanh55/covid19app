<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Pasien;
use App\Slider;
use App\RumahSakit;
use App\Kontak;
use App\NoDarurat;
class ContainerController extends Controller
{
    public function index()
    {   
        // print_r(Pasien::get_home_datas());exit;
    	return view('home/index', [
            'slides' => Slider::all(),
            'rumah_sakit' => RumahSakit::where('rujukan', '1')->get(),
            'kontaks' => Kontak::all(),
            'no_darurat' => NoDarurat::first(),
            'no' => 0,
            'data_per_status' => Pasien::get_home_datas(),
            'latest_update' => Pasien::get_latest_update()
        ]);
    }

    public function kontak()
    {
    	return view('home/kontak');
    }

    public function get_data_chart()
    {
        $data_pasiens = Pasien::get_data_chart();
        $tanggal = array_keys($data_pasiens);
        $data_sembuh = [];$data_meninggal = [];$data_aktif = [];
        $data_odp = [];$data_pdp = [];$data_otg = [];

        foreach($data_pasiens as $i  => $data) {
            $data_sembuh[] = $data_pasiens[$i]['data']['Sembuh'];
            $data_aktif[] = $data_pasiens[$i]['data']['Positif Aktif'];
            $data_meninggal[] = $data_pasiens[$i]['data']['Meninggal'];
            $data_odp[] = $data_pasiens[$i]['data']['ODP'];
            $data_pdp[] = $data_pasiens[$i]['data']['PDP'];
            $data_otg[] = $data_pasiens[$i]['data']['OTG'];
        }
        // print_r(array_reverse($data_sembuh));exit;
        
        return response()->json([
            'status' => TRUE,
            'tanggal' => array_reverse($tanggal),
            'data' => [
               'sembuh' => array_reverse($data_sembuh),
               'aktif' => array_reverse($data_aktif),               
               'meninggal' => array_reverse($data_meninggal),
               'odp' => array_reverse($data_odp),
               'pdp' => array_reverse($data_pdp),
               'otg' => array_reverse($data_otg)
            ]
        ], 200);
    }

    public function get_all_coordinates()
    {
    	$data_pasiens = Pasien::get_coordinates();
    	$datas = [];
        // print_r($data_pasiens);exit;
    	// foreach ($data_pasiens as $key => $value) {
    	// 	foreach($data_pasiens[$key] as $data) {
    	// 		array_push($datas, $data);
    	// 	}
    	// }
		return response()->json([
			'status' => TRUE,
			'data' => $data_pasiens
		], 200);
    }
}
