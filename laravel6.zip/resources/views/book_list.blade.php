<!DOCTYPE html>
<html>
<head>
	<title>Book List - Laravel</title>
</head>
<body>
	<div class="container">
		<h3>Book List</h3>
		<ul>
			<li>Laravel Books</li>
			<li>Vue JS Books</li>
			<li>CSS Books</li>
		</ul>
		<h4>Ordered Book</h4>
		<p>Order No: {{ $order_no }}</p>
		<p>Book type: {{ $book }}</p>
	</div>
</body>
</html>